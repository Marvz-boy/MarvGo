// MarvGo Cyberpunk Script - Full Rewrite

// -------------------------
// DOM Elements
// -------------------------
const searchInput = document.getElementById('searchInput');
const searchButton = document.getElementById('searchButton');
const resultsDiv = document.getElementById('results');
const showRelatedCheckbox = document.getElementById('showRelated');
const liveTypingCheckbox = document.getElementById('liveTyping');

const browserSection = document.getElementById('browser-section');
const marvgoBrowser = document.getElementById('marvgoBrowser');
const closeBrowser = document.getElementById('closeBrowser');

// -------------------------
// Embedded Browser Behavior
// -------------------------
function enableEmbeddedBrowser() {
  const links = resultsDiv.querySelectorAll('a');
  links.forEach(link => {
    link.addEventListener('click', e => {
      e.preventDefault();
      const url = link.href;
      marvgoBrowser.src = url;
      browserSection.style.display = 'block';
    });
  });
}

closeBrowser.addEventListener('click', () => {
  browserSection.style.display = 'none';
  marvgoBrowser.src = '';
});

// -------------------------
// Animated Background
// -------------------------
const canvas = document.getElementById('bgCanvas');
const ctx = canvas.getContext('2d');
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;
let lines = Array.from({length:150}, ()=>({x:Math.random()*canvas.width,y:Math.random()*canvas.height,speed:0.5+Math.random()}));

function animate() {
  ctx.fillStyle = 'rgba(11,12,16,0.1)';
  ctx.fillRect(0,0,canvas.width,canvas.height);
  ctx.strokeStyle = '#00f0ff';
  ctx.lineWidth = 1;
  lines.forEach(line=>{
    line.y-=line.speed;
    if(line.y<0) line.y=canvas.height;
    ctx.beginPath();
    ctx.moveTo(line.x,line.y);
    ctx.lineTo(line.x,line.y+14);
    ctx.stroke();
  });
  requestAnimationFrame(animate);
}
animate();

// -------------------------
// Site Links (embedded browser)
// -------------------------
function yahooLink(){ return "https://www.yahoo.com"; }
function facebookLink(){ return "https://www.facebook.com"; }
function tiktokLink(){ return "https://www.tiktok.com"; }
function chromeLink(){ return "https://www.google.com"; }
function youLink(){ return "https://you.com"; }

// -------------------------
// API Fetches
// -------------------------
async function fetchDuckDuckGo(query){
  try {
    const res = await fetch(`https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json&no_redirect=1`);
    return await res.json();
  } catch(e){ return null; }
}

async function fetchWikipedia(query){
  try{
    const res = await fetch(`https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(query)}`);
    if(!res.ok) return null;
    return await res.json();
  } catch(e){ return null; }
}

// -------------------------
// Card Creation
// -------------------------
function createCard(sourceName, content, link='', cssClass=''){
  const card = document.createElement('div');
  card.classList.add('definition-card', cssClass);
  card.innerHTML = `<p><b>${sourceName}:</b> ${content}</p>` + (link?`<p><a href="${link}">${link}</a></p>`:'');
  card.addEventListener('click', ()=>card.classList.toggle('expanded'));
  return card;
}

function typeText(element,text,speed=20){
  if(!liveTypingCheckbox.checked){ element.innerHTML=text; return; }
  element.innerHTML='';
  let i=0;
  function type(){ if(i<text.length){ element.innerHTML+=text.charAt(i); i++; setTimeout(type,speed); } }
  type();
}

// -------------------------
// Main Function
// -------------------------
async function getDefinition(query){
  if(!query){ resultsDiv.innerHTML='<p class="error-message">Enter a keyword!</p>'; return; }
  resultsDiv.innerHTML='<div class="loader"></div>';

  const duckData = await fetchDuckDuckGo(query);
  const wikiData = await fetchWikipedia(query);
  resultsDiv.innerHTML='';

  // DuckDuckGo
  if(duckData?.AbstractText){
    const card = createCard('DuckDuckGo', duckData.AbstractText, duckData.AbstractURL||'', 'duck');
    typeText(card, `<b>DuckDuckGo:</b> ${duckData.AbstractText}`);
    resultsDiv.appendChild(card);
  }

  // Wikipedia
  if(wikiData?.extract){
    const card = createCard('Wikipedia', wikiData.extract, wikiData.content_urls?.desktop?.page||'', 'wiki');
    typeText(card, `<b>Wikipedia:</b> ${wikiData.extract}`);
    resultsDiv.appendChild(card);
  }

  // Direct sites
  resultsDiv.appendChild(createCard('Yahoo','Open Yahoo',yahooLink(),'yahoo'));
  resultsDiv.appendChild(createCard('Facebook','Open Facebook',facebookLink(),'facebook'));
  resultsDiv.appendChild(createCard('TikTok','Open TikTok',tiktokLink(),'tiktok'));
  resultsDiv.appendChild(createCard('Google','Open Google',chromeLink(),'chrome'));
  resultsDiv.appendChild(createCard('You.com','Open You.com',youLink(),'you'));

  // Related Topics (DuckDuckGo)
  if(showRelatedCheckbox.checked && duckData?.RelatedTopics?.length){
    duckData.RelatedTopics.forEach(topic=>{
      if(topic.Text) resultsDiv.appendChild(createCard('Related Node',topic.Text,topic.FirstURL||'','related'));
    });
  }

  enableEmbeddedBrowser();
}

// -------------------------
// Event Listeners
// -------------------------
searchButton.addEventListener('click', ()=>getDefinition(searchInput.value.trim()));
searchInput.addEventListener('keyup', e=>{ if(e.key==='Enter') getDefinition(searchInput.value.trim()); });
