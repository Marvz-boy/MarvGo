import express from 'express';
import fetch from 'node-fetch';
import dotenv from 'dotenv';
import path from 'path';
dotenv.config();
const app = express();
const PORT = process.env.PORT || 3000;
const API_KEY = process.env.GOOGLE_API_KEY; // <-- your only secret
const CX = process.env.GOOGLE_CSE_ID; // <-- your search engine id (cx)
if(!API_KEY || !CX){
console.warn('WARNING: GOOGLE_API_KEY or GOOGLE_CSE_ID not set in .env');
}
app.use(express.static(path.resolve('./')));
app.get("/search", async (req, res) => {
  const query = req.query.q;
  const apiKey = process.env.GOOGLE_API_KEY;
  const cx = process.env.GOOGLE_CSE_ID;

  if (!query) return res.json({ error: "Missing search query" });

  try {
    const apiUrl = `https://www.googleapis.com/customsearch/v1?key=${apiKey}&cx=${cx}&q=${encodeURIComponent(query)}`;
    const response = await fetch(apiUrl);
    const data = await response.json();

    res.json(data);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Search request failed" });
  }
});
app.get('/search', async (req,res)=>{
try{
const q = req.query.q || '';
if(!q) return res.status(400).json({error:'q param required'});
const url = new URL('https://www.googleapis.com/customsearch/v1');
url.searchParams.set('key', API_KEY);
url.searchParams.set('cx', CX);
url.searchParams.set('q', q);
// you can add more params like num=10, start=1, safe=high
const r = await fetch(url.href);
if(!r.ok){
const body = await r.text();
return res.status(500).send(body);
}
const json = await r.json();
return res.json(json);
}catch(err){
console.error(err);
res.status(500).json({error:err.message});
}
});
app.listen(PORT, ()=>{console.log(`MarvGo dev server running: http://localhost:${PORT}`);});